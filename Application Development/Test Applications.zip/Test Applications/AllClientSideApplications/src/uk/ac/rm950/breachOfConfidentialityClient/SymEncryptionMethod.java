package uk.ac.rm950.breachOfConfidentialityClient;

public enum SymEncryptionMethod {
	SUBSTITUTION, TRANSPOSITION, BLOCKING
};
