package uk.ac.rm950.remoteInterface;

public interface JobInterface<T> {
	T commenceJob();
}
